package play.modules.coval;

import play.PlayPlugin;

public class CovalPlugin extends PlayPlugin {

}
